function c = detrend(c,varargin);

% DETREND removes the slope of each trace.
%
% C = DETREND(C) removes the trend from each trace. In most cases it is
% unnecessary to call this function directly. By default, all traces are
% demeaned and detrended when they are loaded into a correlation object.
% This is one of the assumptions of the correlation toolbox.

% Author: Michael West, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $

c.W = detrend(c.W);