function result = requires_file(ds)
%ISFILEDEPENDENT

result = (ds.usefile == true);