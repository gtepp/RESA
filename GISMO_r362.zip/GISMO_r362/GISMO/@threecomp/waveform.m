function w = waveform(TC)

%WAVEFORM Get waveforms from a threecomp object
%   W = WAVEFORM(TC) Extracts waveforms from a threecomp object where W is
%   a waveform object and TC is a threecomp object.

% Author: Michael West, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $


w = TC.traces;