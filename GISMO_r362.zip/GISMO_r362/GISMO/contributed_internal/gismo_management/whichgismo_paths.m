% Configuration file containing preset paths for whichgismo. See
% whichgismo.m for details.

% Author: Michael West, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-08-01 15:23:39 -0800 (Wed, 01 Aug 2012) $
% $Revision: 351 $


% PREDEFINED PATH
paths = {
    'Op'                '/home/admin/share/matlab/PACKAGES/GISMO_OP/GISMO'
    'Dev'               '/home/admin/share/matlab/PACKAGES/GISMO_DEV/GISMO'
    'West'              '~/Repositories/GISMOTOOLS/GISMO'
    'WestBranch'        '~/Repositories/GISMOBRANCH/GISMO'
    'Glenn'             '/home/glen/src/gismotools/GISMO'  % GT: I can use this on coho, bronco, elsewhere since I always put gismotools at ~/src/
};
