function about

%Tools for checking various types of data integrity.
% These tools are designed to interact with the 
% various databases standard in the UAF Seis Lab.
