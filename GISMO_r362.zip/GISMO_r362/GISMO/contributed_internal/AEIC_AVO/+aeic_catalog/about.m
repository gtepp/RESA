function about

%Tools for interfacing with the AEIC earthquake catalog.
% These tools are designed to interact with the 
% various earthquake catalogs produced by AEIC.
