function about

%Tools for interacting with the IRIS DMC web services.
% The current functions in this package are simple but stand as an example
% of how such functions can be constructed. This customized version of
% xml2struct may prove helpful for those wishing to interact with the web
% services.

help irisdmc;
