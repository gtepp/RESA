function about

%Tools for maintaining and programming in the GISMO environment.
% The admin package provides a series of tools to assist with programming
% in GISMO.

help admin;
