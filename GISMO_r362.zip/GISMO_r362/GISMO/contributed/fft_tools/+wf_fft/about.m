function about

%Miscellaneous tools for working with waveforms.
% Tools in this package are specific enough or customized enough that they
% do not belong as built-in methods for the waveform class.

help wf_fft;
