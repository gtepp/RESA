function about

%Tool(s) for working with SAC files.
% Reading/writing SAC is native to the waveform class. Tools in this
% package may make working with a stack of SAC files easier however.

help sac;
