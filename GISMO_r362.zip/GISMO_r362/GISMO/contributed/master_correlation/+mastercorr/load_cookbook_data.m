function W = load_cookbook_data

%LOAD_COOKBOOK_DATA Load sample data used in MASTERCORR.COOKBOOK 
% W = LOAD_COOKBOOK_DATA loads a sample dataset for use with the
% MASTERCOR.COOKBOOK function. The output W is a waveform object.
%
% See also mastercorr.cookbook

% Author: Michael West, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $




pathName = which('mastercorr.cookbook');
[pathStr,~,~] = fileparts(pathName);
load(fullfile(pathStr,'cookbook_data.mat'));



