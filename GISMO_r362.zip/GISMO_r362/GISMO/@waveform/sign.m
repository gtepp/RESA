function w = sign(w)
%SIGN Signum function for waveforms.
% WAVEFORM = SIGN(WAVEFORM)
% see sign

% AUTHOR: Celso Reyes, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $

for n=1:numel(w)
 % w(n) = set(w(n),'data',sign(double(get(w(n),'data'))));
 w(n).data = sign(w(n).data);
end
w = addhistory(w, 'Each data point changed to its sign (-1, 0, or 1)');
