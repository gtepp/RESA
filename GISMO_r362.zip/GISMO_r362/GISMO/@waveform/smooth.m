function W = smooth(W, varargin)
% SMOOTH overloaded smooth function for waveform
% Differs from MATLAB's smooth function in that it takes one or more
% waveforms instead of a data vector.  
%
% See Also smooth

% AUTHOR: Celso Reyes, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $

for n = 1:numel(W)
    W(n) = set(W(n),'data',smooth(W(n).data,varargin{:}));
end
W = addhistory(W,{'Smoothed with these arguments',varargin});
