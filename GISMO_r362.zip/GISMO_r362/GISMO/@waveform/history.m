function [actions dates] = history(w)
%HISTORY retrieve the history of a waveform object
%   actions = history(waveform)
%       returns a cell of what's been done to this waveform object
%
%   [actions timestamps] = history(waveform)
%       returns a cell of what's been done to this waveform object
%       ACTIONS and a vector array of matlab datenums associated with
%       each action. ie, TIMESTAMPS.
% 
%
% See also WAVEFORM/ADDHISTORY, WAVEFORM/CLEARHISTORY, WAVEFORM/GET.

% HISTORY recording is controlled by global WAVEFORM_HISTORY from
% waveform/waveform

% AUTHOR: Celso Reyes, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $

if numel(w) > 1
    error('Waveform:history:tooManyWaveforms',...
      '''waveform/history()'' can only retrieve history for individual waveforms');
end
val = w.history;
actions = val(:,1);
dates = datestr([val{:,2}]');

