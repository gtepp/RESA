% EPOCH = DATENUM2EPOCH(TIME) translates Matlab numeric 
% date format into Unix epoch date format. Requires the 
% Antelope tool box.
%

% Author: Michael West, Geophysical Institute, Univ. of Alaska Fairbanks
% $Date: 2012-04-11 08:15:09 -0800 (Wed, 11 Apr 2012) $
% $Revision: 348 $

function epoch = datenum2epoch(time)

epoch = zeros(size(time));
for n = 1:numel(time)
    epoch(n) = str2epoch(datestr(time(n),'mm/dd/yyyy HH:MM:SS.FFF'));
end

% epoch = reshape(epoch,size(time)); % no longer necessary with ZEROS definition
